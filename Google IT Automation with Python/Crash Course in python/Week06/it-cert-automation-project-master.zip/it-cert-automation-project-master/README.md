# Google IT Automation with Python Professional Certificate
## Final project files

This repository contains the files needed to work on the final project of the
specialization.

It's divided in the same 4 parts as the final project. Each directory contains
the files used in the course to complete the exercises.

Starting from Part 2, it's recommended that the scripts are run inside a
virtual machine. This could be a VM running in the Cloud, or a local virtual
machine using virtualizing software, like VMWare, Virtual Box, or Libvirtd.
